// kl_prefs_62fbb8f7_c917_4cf7_957a_aad2b8fa768c.js
pref("general.config.obscure_value", 0);
pref("general.config.filename", "kl_config_62fbb8f7_c917_4cf7_957a_aad2b8fa768c.cfg");
